export interface TipoOcorrencia {
    // [x: string]: any;
    idTipoOcorrencia?: number; 
    descricao: string; 
}
