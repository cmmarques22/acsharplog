export interface Especie {
    idEspecie?: number;
    classe: string;
    especie1: string;
}
